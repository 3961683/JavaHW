package com.company.Classes;

public class Parrot extends Animal {

    public Parrot(double weight, int age) {
        super(weight, age);
    }


    public static void PlaySound() {
        System.out.println("Squawk");
    }

    @Override
    public void ShowName() {
        System.out.println("I am a parrot");
    }


}
