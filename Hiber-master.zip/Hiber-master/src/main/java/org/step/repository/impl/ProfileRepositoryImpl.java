package org.step.repository.impl;

import org.hibernate.Session;
import org.step.entity.Profile;
import org.step.repository.ProfileRepository;
import org.step.repository.SessionFactoryCreator;

import javax.persistence.EntityManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class ProfileRepositoryImpl implements ProfileRepository {
    @Override
    public List<Profile> findAll() {
        Session session = SessionFactoryCreator.getSession();

        session.getTransaction().begin();

        List<Profile> profiles = session.createQuery("SELECT p from Profile p",Profile.class).getResultList();

        session.getTransaction().commit();

        session.close();

        return profiles;
    }

    @Override
    public List<Profile> findById(Long id) {
        Session session = SessionFactoryCreator.getSession();

        session.getTransaction().begin();

        //----
        List<Profile> profiles = new ArrayList<>();
        //----

        session.doWork(connection -> {
            PreparedStatement preparedStatement = connection.prepareStatement("SELECT * FROM profiles p WHERE p.id=?");
            preparedStatement.setLong(1,id);

            ResultSet resultSet = preparedStatement.executeQuery();

            while(resultSet.next()){
                profiles.add(
                        Profile.builder()
                                .id(resultSet.getLong("id"))
                                .fullName(resultSet.getString("full_name"))
                                .abilities(resultSet.getString("abilities"))
                                .graduation(resultSet.getString("graduation"))
                                .workExperience(resultSet.getString("work_experience"))
                                .build()
                );
            }
        });

        session.getTransaction().commit();

        session.close();
        return profiles;
    }

    @Override
    public List<Profile> findByFullName(String fullName) {
        Session session = SessionFactoryCreator.getSession();

        session.getTransaction().begin();

        List<Profile> profiles = new ArrayList<>();

        session.doWork(connection -> {
            PreparedStatement preparedStatement = connection.prepareStatement("SELECT * FROM Profiles WHERE full_name=?");
            preparedStatement.setString(1,fullName);

            ResultSet resultSet = preparedStatement.executeQuery();

            while(resultSet.next()){
                profiles.add(
                        Profile.builder()
                                .id(resultSet.getLong("id"))
                                .fullName(resultSet.getString("full_name"))
                                .abilities(resultSet.getString("abilities"))
                                .graduation(resultSet.getString("graduation"))
                                .workExperience(resultSet.getString("work_experience"))
                                .build()
                );
            }

        });
        session.getTransaction().commit();

        session.close();
        return profiles;
    }

    @Override
    public void deleteProfile(Long id) {
        Session session = SessionFactoryCreator.getSession();

        session.getTransaction().begin();

        session.createNativeQuery("delete from profiles where ID=:id")
                .setParameter("id",id).executeUpdate();

        session.getTransaction().commit();
        session.close();
    }
}
