package org.step.entity;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "views")
public class Views {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE,generator = "seq_gen")
    @SequenceGenerator(name = "seq_gen",sequenceName = "SeqId",allocationSize = 1)
    @Column(name = "id")
    private Long id;

    @Column(name = "Date")
    private String DateView;

    @ManyToOne(fetch = FetchType.LAZY)
        @JoinColumn(
            name = "profile_id",
            foreignKey = @ForeignKey(name = "views_profile_fk")
    )
    private Profile profile;

    public Views(Long id,String dateView) {
        this.id = id;
        this.DateView = dateView;
    }

    public static ViewsBuilder builder(){return new ViewsBuilder();}

    public static class ViewsBuilder{
        private Long id;
        private String DateView;

        public ViewsBuilder(){

        }

        public ViewsBuilder Id(Long id){
            this.id = id;
            return this;
        }

        public ViewsBuilder Date(String date){
            this.DateView = date;
            return this;
        }

        public Views build(){return new Views(id,DateView);}
    }

    public String getDateView() {
        return DateView;
    }

    public void setDateView(String dateView) {
        DateView = dateView;
    }

    public Profile getProfile() {
        return profile;
    }

    public void setProfile(Profile profile) {
        this.profile = profile;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Views views = (Views) o;
        return Objects.equals(id, views.id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }
}
