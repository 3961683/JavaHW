package com.company.Classes;

public class Lion extends Animal {

    public Lion(double weight, int age) {
        super(weight, age);
    }

    public static void PlaySound() {
        System.out.println("Rawr");
    }

    @Override
    public void ShowName() {
        System.out.println("I am a lion");
    }
}
