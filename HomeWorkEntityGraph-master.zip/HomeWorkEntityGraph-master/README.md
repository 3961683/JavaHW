# LinkedStep
Study project for Hibernate, Spring. Fourth class.
