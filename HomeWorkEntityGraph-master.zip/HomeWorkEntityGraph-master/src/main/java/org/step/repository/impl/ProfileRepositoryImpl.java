package org.step.repository.impl;

import org.hibernate.Session;
import org.hibernate.annotations.QueryHints;
import org.step.entity.Profile;
import org.step.repository.ProfileRepository;
import org.step.repository.SessionFactoryCreator;

import javax.persistence.EntityGraph;
import javax.persistence.EntityManager;
import java.util.List;

import static org.step.entity.Profile.PROFILE_VIEWS_GRAPHS;

public class ProfileRepositoryImpl implements ProfileRepository {

    private final EntityManager entityManager = SessionFactoryCreator.getEntityManager();

    @Override
    public Profile save(Profile profile) {
        entityManager.getTransaction().begin();

        entityManager.persist(profile);

        entityManager.getTransaction().commit();

        return profile;
    }

    @Override
    public List<Profile> findAll() {
        entityManager.getTransaction().begin();
        EntityGraph<?> profileViewsGraph = entityManager.getEntityGraph(PROFILE_VIEWS_GRAPHS);

        List<Profile> profiles = entityManager.createQuery("select p from Profile p")
                .setHint(QueryHints.READ_ONLY,true)
                .setHint("javax.persistence.fetchgraph",profileViewsGraph)
                .getResultList();

        entityManager.getTransaction().commit();
        return profiles;
    }

    @Override
    public void delete(Long id) {
        entityManager.getTransaction().begin();

        entityManager.createQuery("delete from Views v where v.profile.id=:id")
                .setParameter("id",id)
                .executeUpdate();

        entityManager.createQuery("delete from Profile where ID=:id")
                .setParameter("id",id).executeUpdate();

        entityManager.getTransaction().commit();
    }

    @Override
    public void updateProfile(String fullName, Long id) {
        entityManager.getTransaction().begin();

        Profile profile = entityManager.find(Profile.class,id);

        profile.setFullName(fullName);

        entityManager.getTransaction().commit();
    }

    @Override
    public List<Profile> findAllUsingSession() {
        EntityGraph<Profile> profileEntityGraph = entityManager.createEntityGraph(Profile.class);

        profileEntityGraph.addAttributeNodes("viewsList");

        return entityManager.createQuery("select p from Profile p",Profile.class)
                .setHint(QueryHints.READ_ONLY,true)
                .setHint("javax.persistence.fetchgraph",profileEntityGraph)
                .getResultList();
    }
}
