package org.HiberNT;

import org.HiberNT.Service.UserService;
import org.HiberNT.entities.User;

import java.util.HashSet;

public class Main {
    public static void main(String[] args) {
        UserService userService = new UserService();

        HashSet<User> users = new HashSet<User>();
        users.add(new User(1L,"Kenesary"));
        users.add(new User(2L,"Miras"));
        users.add(new User(3L,"Arman"));

        userService.SaveUsers(users);
        userService.UpdateUser("Aidos",3L);
    }
}
