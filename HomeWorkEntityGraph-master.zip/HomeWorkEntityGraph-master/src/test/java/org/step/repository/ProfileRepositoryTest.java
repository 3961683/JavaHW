package org.step.repository;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.step.entity.Profile;
import org.step.entity.User;
import org.step.entity.Views;
import org.step.repository.impl.ProfileRepositoryImpl;

import javax.persistence.EntityManager;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class ProfileRepositoryTest {

    private final ProfileRepository profileRepository = new ProfileRepositoryImpl();
    private final EntityManager entityManager = SessionFactoryCreator.getEntityManager();
    private final List<Profile> profiles = new ArrayList<>();

    @Before
    public void setup() {
        Profile profile = Profile.builder()
                .abilities("abilities")
                .graduation("graduation")
                .workExperience("experience")
                .fullName("Lora Paul")
                .build();

        Views views1 = Views.builder()
                .Date("19/09/20")
                .build();

        Views views2 = Views.builder()
                .Date("18/09/20")
                .build();

        Views views3 = Views.builder()
                .Date("01/07/20")
                .build();

        profile.addViews(views1);
        profile.addViews(views2);
        profile.addViews(views3);

        entityManager.getTransaction().begin();

        entityManager.persist(profile);

        entityManager.getTransaction().commit();

        profiles.add(profile);
    }
    @After
    public void clean() {
        entityManager.getTransaction().begin();

        entityManager.createQuery("delete from Views v").executeUpdate();

        entityManager.createQuery("delete from Profile p").executeUpdate();

        entityManager.getTransaction().commit();
    }

    @Test
    public void TestWithJoinFetch(){
        List<Profile> profiles = entityManager.createQuery("select p from Profile p join fetch p.viewsList").getResultList();

        Assert.assertNotNull(profiles);
        Assert.assertFalse(profiles.isEmpty());
    }

    @Test
    public void TestFindAll(){
        List<Profile> profiles = profileRepository.findAll();

        profiles.forEach(c-> System.out.println(c.getFullName()));

        Assert.assertNotNull(profiles);
        Assert.assertFalse(profiles.isEmpty());
    }

    @Test
    public void TestSave(){
        Profile profile = Profile.builder()
                .abilities("abilities")
                .graduation("graduation")
                .workExperience("workExp")
                .fullName("CakeKulich")
                .build();

        Views views1 = Views.builder()
                .Date("19/09/20")
                .build();

        Views views2 = Views.builder()
                .Date("17/01/20")
                .build();

        profile.addViews(views1);
        profile.addViews(views2);

        profileRepository.save(profile);
    }

    @Test
    public void TestUpdate(){
        int idi = 0;
        Long id = profiles.get(0).getId();
        profileRepository.updateProfile("Lola Rola",id);
    }

    @Test
    public void TestDelete(){
        int idi = 0;
        Long id = profiles.get(0).getId();
        profileRepository.delete(id);
    }

    @Test
    public void TestfindAllUsingSession(){
        List<Profile> profiles = profileRepository.findAllUsingSession();

        profiles.forEach(e->{
            System.out.println(e.getFullName());
            e.getViewsList().forEach(ein->{
                System.out.println(ein.getId()+" : "+ein.getDateView());
            });
        });
    }
}
