package org.step.repository;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.step.entity.Profile;
import org.step.repository.impl.ProfileRepositoryImpl;

import javax.persistence.EntityManager;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class ProfileRepositoryTest {

    private final ProfileRepository profileRepository = new ProfileRepositoryImpl();
    private final EntityManager entityManager = SessionFactoryCreator.getEntityManager();
    private final List<Profile> profiles = new ArrayList<>();

    @Before
    public void setup() {
        Profile profile = Profile.builder()
                .abilities("abilities")
                .graduation("graduation")
                .workExperience("experience")
                .fullName("RodionGarbach")
                .build();

        Profile profile1 = Profile.builder()
                .abilities("abl")
                .graduation("grad")
                .workExperience("exp")
                .fullName("JakeFine")
                .build();

        Profile profile2 = Profile.builder()
                .abilities("abl1")
                .graduation("grad1")
                .workExperience("exp1")
                .fullName("KulichCake")
                .build();

        entityManager.getTransaction().begin();

        entityManager.persist(profile);
        entityManager.persist(profile1);
        entityManager.persist(profile2);

        entityManager.getTransaction().commit();

        profiles.add(profile);
        profiles.add(profile1);
        profiles.add(profile2);
    }

    @After
    public void clean() {
        entityManager.getTransaction().begin();

        entityManager.createQuery("delete from Profile p").executeUpdate();

        entityManager.getTransaction().commit();
    }

    @Test
    public void findAllTest(){
        List<Profile> profilesIn = profileRepository.findAll();

        Assert.assertNotNull(profilesIn);
        Assert.assertFalse(profilesIn.isEmpty());
        Assert.assertTrue(profilesIn.contains(Profile.builder().id(profiles.get(0).getId()).build()));
    }

    @Test
    public void findByFullNameTest(){
        List<Profile> profilesIn = profileRepository.findByFullName("KulichCake");

        System.out.println(profilesIn.get(0));
        Assert.assertNotNull(profilesIn);
        Assert.assertFalse(profilesIn.isEmpty());
        Assert.assertTrue(profilesIn.contains(Profile.builder().id(profiles.get(2).getId()).build()));
    }

    @Test
    public void findByIdTest(){
        List<Profile> profilesAll = profileRepository.findAll();
        Long id = profilesAll.get(0).getId();
        List<Profile> profilesIn = profileRepository.findById(id);
        Assert.assertNotNull(profilesIn);
        Assert.assertFalse(profilesIn.isEmpty());
        //Assert.assertTrue(profilesIn.contains(Profile.builder().id(profiles.get(0).getId()).build()));
    }

    @Test
    public void deleteByIdTest(){
        List<Profile> profilesIn = profileRepository.findAll();
        profileRepository.deleteProfile(profilesIn.get(0).getId());
    }
}
