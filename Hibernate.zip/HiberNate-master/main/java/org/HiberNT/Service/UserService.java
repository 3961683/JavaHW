package org.HiberNT.Service;

import org.HiberNT.entities.User;
import org.HiberNT.repository.UserRepository;

import java.util.HashSet;
import java.util.Set;

public class UserService {
    private UserRepository userRepository;

    public UserService(){
        userRepository = new UserRepository();
    }

    public void SaveUser(User user){
        userRepository.saveUser(user);
    }

    public void UpdateUser(String name,Long id){
        userRepository.updateUsername(name,id);
    }

    public void SaveUsers(HashSet<User> userSet){
        userRepository.SaveUsers(userSet);
    }
}
