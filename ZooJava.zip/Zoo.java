package com.company.Classes;

import java.util.ArrayList;

public class Zoo {
    private ArrayList<Animal> animals = new ArrayList<>();

    public Zoo() {    }

    public void ShowZoo() {
        for (Animal a: animals) {
            a.ShowName();
            a.ShowInformation();
        }
    }

    public void AddAnimal(Animal animal) { animals.add(animal); }

    public void ShowLions() {
        for (Animal a: animals) {
            if (a instanceof Lion) {
                a.ShowName();
                a.ShowInformation();
            }
        }
    }

    public void ShowWolfs(){
        for (Animal a: animals) {
            if (a instanceof Wolf) {
                a.ShowName();
                a.ShowInformation();
            }
        }
    }

    public void ShowParrots(){
        for (Animal a: animals) {
            if (a instanceof Parrot) {
                a.ShowName();
                a.ShowInformation();
            }
        }
    }

    public void AddTestValues() {
        animals.add(new Lion(187,11));
        animals.add(new Lion(134,8));
        animals.add(new Lion(112,9));

        animals.add(new Parrot(0.6,10));
        animals.add(new Parrot(0.9,24));
        animals.add(new Parrot(1.6,17));

        animals.add(new Wolf(79,20));
        animals.add(new Wolf(45,13));
        animals.add(new Wolf(29, 8));
    }
}
