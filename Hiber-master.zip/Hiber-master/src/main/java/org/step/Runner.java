package org.step;

public class Runner {

    public static void main(String[] args) {
        System.out.println("Hello world");
    }
}
