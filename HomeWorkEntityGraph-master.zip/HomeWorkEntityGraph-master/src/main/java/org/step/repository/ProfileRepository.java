package org.step.repository;

import org.step.entity.Profile;

import java.util.List;

public interface ProfileRepository extends CrudRepository<Profile> {
    void updateProfile(String fullName, Long id);

    List<Profile> findAllUsingSession();
}
