package org.HiberNT.repository;

import org.junit.Test;

import java.util.Map;

public class ConnectionRepositoryTest {
    @Test
    public void test() {
        Connection connectionRepository = new Connection();

        Map<String, Object> informationFromDatabase = connectionRepository.getInformationFromDatabase();

        System.out.println(informationFromDatabase);
    }
}
