package com.company.Classes;

public abstract class Animal {
    protected double weight;
    protected int age;


    public abstract void ShowName();

    public Animal(double weight, int age) {
        this.weight = weight;
        this.age = age;
    }

    public void ShowInformation() {
        System.out.println("Height: " + weight + "\nAge: " + age);
    }

}
